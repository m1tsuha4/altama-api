-- AlterTable
ALTER TABLE "Career" ADD COLUMN     "link" TEXT,
ALTER COLUMN "overview" DROP NOT NULL;
